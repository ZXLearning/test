/*****************************************************************************

  The following code is derived, directly or indirectly, from the SystemC
  source code Copyright (c) 1996-2014 by all Contributors.
  All Rights reserved.

  The contents of this file are subject to the restrictions and limitations
  set forth in the SystemC Open Source License (the "License");
  You may not use this file except in compliance with such restrictions and
  limitations. You may obtain instructions on how to receive a copy of the
  License at http://www.accellera.org/. Software distributed by Contributors
  under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF
  ANY KIND, either express or implied. See the License for the specific
  language governing rights and limitations under the License.

 *****************************************************************************/

/*****************************************************************************

  sc_signal.h -- The sc_signal<T> primitive channel class.

  Original Author: Martin Janssen, Synopsys, Inc., 2001-05-21

  CHANGE LOG IS AT THE END OF THE FILE
 *****************************************************************************/

#ifndef SC_VLOG_SIGNAL_H
#define SC_VLOG_SIGNAL_H

#include "sysc/communication/sc_port.h"
#include "sysc/communication/sc_prim_channel.h"
#include "sysc/communication/sc_signal_ifs.h"
#include "sysc/communication/sc_writer_policy.h"
#include "sysc/kernel/sc_event.h"
#include "sysc/kernel/sc_process.h"
#include "sysc/kernel/sc_simcontext.h"
#include "sysc/datatypes/bit/sc_logic.h"
#include "sysc/tracing/sc_trace.h"
#include <typeinfo>

using namespace sc_core;
using namespace std;
using namespace sc_dt;

// to avoid code bloat in sc_signal<T>

//extern void sc_deprecated_get_data_ref();
//extern void sc_deprecated_get_new_value();
//extern void sc_deprecated_trace();
//extern sc_event * sc_lazy_kernel_event( sc_event**, const char* name );


// ----------------------------------------------------------------------------
//  CLASS : sc_signal<T>
//
//  The sc_signal<T> primitive channel class.
// ----------------------------------------------------------------------------

template< class T, sc_writer_policy POL  = SC_DEFAULT_WRITER_POLICY >
class sc_vlog_signal
  : public    sc_signal_inout_if<T>, public sc_object
  , protected sc_writer_policy_check<POL>
{
protected:
    typedef sc_signal_inout_if<T>       if_type;
    typedef sc_vlog_signal<T,POL>            this_type;
    typedef sc_writer_policy_check<POL> policy_type;

public: // constructors and destructor:

    sc_vlog_signal()
	: 
	  m_change_event_p( 0 ), m_cur_val( T() ), 
	  m_change_stamp( ~sc_dt::UINT64_ONE ), m_new_val( T() )
	{}

    explicit sc_vlog_signal( const char* name_)
	: m_change_event_p( 0 ), m_cur_val( T() ), 
	  m_change_stamp( ~sc_dt::UINT64_ONE ), m_new_val( T() )
    {}

    sc_vlog_signal( const char* name_, const T& initial_value_ )
      : 
       m_change_event_p( 0 )
      , m_cur_val( initial_value_ )
      , m_change_stamp( ~sc_dt::UINT64_ONE )
      , m_new_val( initial_value_ )
    {}

    virtual ~sc_vlog_signal()
	{
	    delete m_change_event_p;
	}

		inline void request_update(){};
    // interface methods

    virtual void register_port( sc_port_base&, const char* );

    virtual sc_writer_policy get_writer_policy() const
      { return POL; }

    // get the default event
    virtual const sc_event& default_event() const
      { return value_changed_event(); }

    // get the value changed event
    virtual const sc_event& value_changed_event() const
    {
        return *sc_lazy_kernel_event( &m_change_event_p
                                    , "value_changed_event");
    }


    // read the current value
    virtual const T& read() const
	{ return m_cur_val; }

    // get a reference to the current value (for tracing)
    virtual const T& get_data_ref() const
        { sc_deprecated_get_data_ref(); return m_cur_val; }


    // was there an event?
    virtual bool event() const
        { return simcontext()->event_occurred(m_change_stamp); }

    // write the new value
    virtual void write( const T& );


    // other methods

    operator const T& () const
	{ return read(); }


    this_type& operator = ( const T& a )
	{ write( a ); return *this; }

    this_type& operator = ( const sc_signal_in_if<T>& a )
	{ write( a.read() ); return *this; }

    this_type& operator = ( const this_type& a )
	{ write( a.read() ); return *this; }


    const T& get_new_value() const
        { sc_deprecated_get_new_value(); return m_new_val; }


    void trace( sc_trace_file* tf ) const
	{ 
	    sc_deprecated_trace();
#           ifdef DEBUG_SYSTEMC
	        sc_trace( tf, read(), name() ); 
#           else
                if ( tf ) {}
#	    endif
	}


    virtual void print( ::std::ostream& = ::std::cout ) const;
    virtual void dump( ::std::ostream& = ::std::cout ) const;

    virtual const char* kind() const
        { return "sc_vlog_signal"; }

//-----------------
   void wait()
        { sc_core::wait( simcontext() ); }


    // dynamic sensitivity for SC_THREADs and SC_CTHREADs

    void wait( const sc_event& e )
        { sc_core::wait( e, simcontext() ); }

    void wait( const sc_event_or_list& el )
    { sc_core::wait( el, simcontext() ); }

    void wait( const sc_event_and_list& el )
    { sc_core::wait( el, simcontext() ); }

    void wait( const sc_time& t )
        { sc_core::wait( t, simcontext() ); }

    void wait( double v, sc_time_unit tu )
        { sc_core::wait( sc_time( v, tu, simcontext() ), simcontext() ); }

    void wait( const sc_time& t, const sc_event& e )
        { sc_core::wait( t, e, simcontext() ); }

    void wait( double v, sc_time_unit tu, const sc_event& e )
        { sc_core::wait( sc_time( v, tu, simcontext() ), e, simcontext() ); }

    void wait( const sc_time& t, const sc_event_or_list& el )
        { sc_core::wait( t, el, simcontext() ); }

    void wait( double v, sc_time_unit tu, const sc_event_or_list& el )
        { sc_core::wait( sc_time( v, tu, simcontext() ), el, simcontext() ); }

    void wait( const sc_time& t, const sc_event_and_list& el )
        { sc_core::wait( t, el, simcontext() ); }

    void wait( double v, sc_time_unit tu, const sc_event_and_list& el )
        { sc_core::wait( sc_time( v, tu, simcontext() ), el, simcontext() ); }

  void next_trigger()
    { sc_core::next_trigger( simcontext() ); }


    // dynamic sensitivity for SC_METHODs

    void next_trigger( const sc_event& e )
        { sc_core::next_trigger( e, simcontext() ); }

    void next_trigger( const sc_event_or_list& el )
        { sc_core::next_trigger( el, simcontext() ); }

    void next_trigger( const sc_event_and_list& el )
        { sc_core::next_trigger( el, simcontext() ); }

    void next_trigger( const sc_time& t )
        { sc_core::next_trigger( t, simcontext() ); }

    void next_trigger( double v, sc_time_unit tu )
        {sc_core::next_trigger( sc_time( v, tu, simcontext() ), simcontext() );}

    void next_trigger( const sc_time& t, const sc_event& e )
        { sc_core::next_trigger( t, e, simcontext() ); }

    void next_trigger( double v, sc_time_unit tu, const sc_event& e )
        { sc_core::next_trigger(
        sc_time( v, tu, simcontext() ), e, simcontext() ); }

    void next_trigger( const sc_time& t, const sc_event_or_list& el )
        { sc_core::next_trigger( t, el, simcontext() ); }

    void next_trigger( double v, sc_time_unit tu, const sc_event_or_list& el )
        { sc_core::next_trigger(
        sc_time( v, tu, simcontext() ), el, simcontext() ); }


   bool timed_out()
    { return sc_core::timed_out( simcontext() ); }
//--------------

protected:

    virtual void update();
            void do_update();

protected:

    mutable sc_event*  m_change_event_p;
    T                  m_cur_val;
    sc_dt::uint64      m_change_stamp;   // delta of last event
    T                  m_new_val;

private:

    // disabled
    sc_vlog_signal( const this_type& );
};


// IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII


template< class T, sc_writer_policy POL >
inline
void
sc_vlog_signal<T,POL>::register_port( sc_port_base& port_
                               , const char* if_typename_ )
{

    bool is_output = std::string( if_typename_ ) == typeid(if_type).name();
    if( !policy_type::check_port( this, &port_, is_output ) )
       ((void)0); // fallback? error has been suppressed ...
}


// write the new value

template< class T, sc_writer_policy POL >
inline
void
sc_vlog_signal<T,POL>::write( const T& value_ )
{
    bool value_changed = !( m_cur_val == value_ );
    if ( !policy_type::check_write(this, value_changed) )
        return;

    m_new_val = value_;
    if( value_changed ) {
        request_update();
    }
}


template< class T, sc_writer_policy POL >
inline
void
sc_vlog_signal<T,POL>::print( ::std::ostream& os ) const
{
    os << m_cur_val;
}

template< class T, sc_writer_policy POL >
void
sc_vlog_signal<T,POL>::dump( ::std::ostream& os ) const
{
    os << "     name = " << name() << ::std::endl;
    os << "    value = " << m_cur_val << ::std::endl;
    os << "new value = " << m_new_val << ::std::endl;
}


template< class T, sc_writer_policy POL >
void
sc_vlog_signal<T,POL>::update()
{
    policy_type::update();
    if( !( m_new_val == m_cur_val ) ) {
        do_update();
    }
}

template< class T, sc_writer_policy POL >
void
sc_vlog_signal<T,POL>::do_update()
{
    m_cur_val = m_new_val;
   // if ( m_change_event_p ) m_change_event_p->notify_next_delta();
    m_change_stamp = simcontext()->change_stamp();
}

//Revision 1.18  2005/06/10 22:43:55  acg
//Added CVS change log annotation.
//

#endif

// Taf!
