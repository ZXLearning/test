
#include "paramDB.h"
#include<iostream>


 paramDB*	paramDB::_instance =NULL;

paramDB* paramDB::Instance(){
	if( _instance)
		return _instance;
	_instance = new paramDB();
	return _instance;

}

string paramDB::getParam(string p){
	//return Params[p];
	map<string, string>::iterator it;
    for (it = Params.begin(); it != Params.end(); ++it)
    {
     //   std::cout << "geting key " << it->first << std::endl;
     //   std::cout << "value " << it->second << std::endl;
	   if(p.compare(it->first) == 0)
		return it->second ;
    }
	return NULL;

}

int paramDB::setParam(string p, string v){
	//Params[p] = v;
	Params.insert(pair<string,string>(p, v)  );
}


