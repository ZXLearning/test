#ifndef __SIGNAL_H__
#define __SIGNAL_H__
#include <vector>
#include <string>
#include <map>
#include <ostream>
//#include <cmntypes.h>
//#include "event.h"
//#include "bitvector.h"
//#include "export_hydra.h"


class Signal;
typedef  Signal* SignalPtr;

enum SignalAccessType {
  SignalNoAccess        = 0x0,        ///< No Access  
  SignalReadAccess      = 0x1,        ///< Read Access
  SignalWriteAccess     = 0x2,        ///< Write Access
  SignalReadWriteAccess = 0x3,        ///< Write Access
  SignalForceAccess     = 0x4,        ///< Force Access to Net 
} ; 
  
enum SignalEventType { 
    SignalNoEvent       = 0x0,        ///< No Event
    SignalPosedgeEvent  = 0x1,        ///< Posedge Event
    SignalNegedgeEvent  = 0x2,        ///< Negedge Event
    SignalAnyedgeEvent  = 0x4,        ///< Anyedge Event
    SignalValueEvent    = 0x8,        ///< Value Change Event
} ; 
  

/*
class Signal{
public:

/// Determines Access Restrictions / Enables for Signal
//	friend class SignalMgr ; 
//  friend std::ostream & operator<< ( std::ostream & , const Signal & ) ; 

public:

  Signal (const std::string & signal_name,                
	  const std::string & sim_hierarchy, 
	  uint32 signal_size, 
	  SignalAccessType signalaccess,
	  SignalEventType signalevent = SignalNoEvent      
	  );                                                ///< Signal Constructor
protected:
  virtual ~Signal (void);                                   ///< Only SignalMgr is allowed to delete Signals
  
public:
  const std::string & GetName() const { return mName ; } ; ///< Get Name of Signal
  const std::string & GetHierarchy() const { return mHierarchy ; } ; ///< Get Hierearchy Name of Signal
  std::string GetFullName () const ;                       ///< Signal Full Name 

  virtual void Write ( uint32 aWriteVal ) ;                ///< Write integer into Signal 
  virtual void Write ( const std::vector<uint32> & aWriteVec ) ; ///< Write std::vector into Signal
  virtual void Write ( const BitVector & aWriteBitVec ) ;  ///< Write BitVector into Signal

  virtual uint32 Read ( ) ;                                ///< Read lowest 32 bits of Signal
  virtual std::vector<uint32> ReadV ( ) ;                  ///< Read Entire Signal to vector<uint32>
  virtual BitVector ReadBV ( ) ;                           ///< Read EntireSignal to BitVector 
  virtual const BitVector & ReadBVRef ( ) ;                ///< Read EntireSignal to BitVector &

  virtual void Force(uint32 value);                        ///< Force Net to integer value 
  virtual void Force(const std::vector <uint32> & aForceVec ); ///< Force Net to vector<uint32> value
  virtual void Force(const BitVector & aForceBitVec );     ///< Force Net to BitVector vale
  virtual void Release() ;                                 ///< Stop driving net
  bool IsForceEnabled() const { return mIsForcing ; } ;    ///< Is net currently forcing

  void Notify ( SignalEventType aSigEvent );               ///< Notify particular Event type
  virtual void Wait(SignalEventType aSigEvent, uint64 aEventCount=1); ///< Wait given number of SignalEventType's

  Event & GetEvent ( ) const ;                             ///< Returns Event reference to whichever Event is enabled
  Event & GetEvent ( SignalEventType ) const ;             ///< Returns Event reference to specific Event if enabled throws if not
  EventPtr GetEventPtr ( ) const ;                          ///< Returns EventPtr to whichever Event is enabled
  EventPtr GetEventPtr ( SignalEventType ) const ;          ///< Returns EventPtr to specific Event if enabled throws if not

  template <class ComparePred>
  void WaitOn ( ComparePred cmp ) ;                         ///< Allows for functions to wait on signal values

  bool IsEventEnabled(SignalEventType signal_event) const ; ///< Find if an event is enabled 
  uint32 GetSize () const ;                                 ///< Get the size of the Signal

  virtual void EndOfElab ();                                ///< EndOfElab call

protected:
  virtual std::ostream & out ( std::ostream & os ) const ;  ///< Virtual Function for display 

protected:
  std::string               mName ;                         ///< Name of signal
  std::string               mHierarchy ;                    ///< Name of instance where signal is attached
  BitVector                 mValue ;                        ///< Value of Signal 
  BitVector                 mOldValue ;                     ///< Value of Temp Signal (same size as mValue)
  BitVector                 mDelayedInitialValue ;          ///< Delayed Initial Value to be written at end of elab
  SignalAccessType          mAccessRestriction;             ///< Type of access allowed on Signal
  SignalEventType           mSignalEventAvailable;          ///< Mask of Event Types attached
  bool                      mIsForcing;                     ///< State of Force Bits
  SignalEventPtrMap         mEventPtrMap ;                  ///< Maps SignalTypes to Event Pointers
  bool                      mDelayedInitialValueForced ;    ///< Flag to tell if initial value is forced or just write
  bool                      mIsDelayedInitialValue ;        ///< Flag to tell if there is an initial value is forced or just write
  bool                      mAfterEndOfElab;                ///< Flag to tell if After End of Elab
} ; 
///@}

std::ostream & operator<< ( std::ostream & os , const Signal & aSignal ) ; 

template <class ComparePred>
void
Signal::WaitOn ( ComparePred cmp ) { 

  while ( ! cmp(this) ) { 
    mEventPtrMap[SignalValueEvent]->Wait() ; 
  }

}
#ifdef WIN_OS
#pragma warning( pop )
#endif

#endif // __ATI_SIGNAL_H__

};
*/

class Signal
{
public:

  Signal (const std::string & signal_name,                
	  const std::string & sim_hierarchy, 
	  uint32 signal_size, 
	  SignalAccessType signalaccess,
	  SignalEventType signalevent = SignalNoEvent      
	  );                                                ///< Signal Constructor
protected:
  virtual ~Signal (void);                                   ///< Only SignalMgr is allowed to delete Signals
  
public:
  const std::string & GetName() const { return mName ; } ; ///< Get Name of Signal
  const std::string & GetHierarchy() const { return mHierarchy ; } ; ///< Get Hierearchy Name of Signal
  std::string GetFullName () const ;                       ///< Signal Full Name 

  virtual void Write ( uint32 aWriteVal ) ;
  sc_event GetEvent();
  void Notify();
  void Wait();

protect:
	sc_event mScEvent;
	std::string mName;
	std::string nHierarchy;
}

#endif
