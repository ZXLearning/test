
#ifndef __PARAMDB_H__
#define __PARAMDB_H__

#include<string>
#include<map>
#include<assert.h>

using namespace std;

class paramDB{

public:
	map<string, string> Params;
	paramDB(){
	assert(!_instance);
	}

static	paramDB * _instance;

static	paramDB * Instance();

	void LoadConfigFile(string file);

	string getParam(string p);
	int setParam(string p, string v);



};






#endif
