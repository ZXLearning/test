#ifndef __HYPROCESS_H__
#define __HYPROCESS_H__

#include "systemc.h"
#include <vector>
/*
HyProcess persent a function/method will be spawned later.
use to model Phase's Thtrad.
*/


using namespace sc_core;

const int SC_THREAD_DEFAULT_STACK_SIZE   = 0x100000;

class HyProcess
{
HyProcess(){}
public:
virtual sc_process_handle Spawn() = 0;


};

template<class CLASS, typename RETURN, typename ARG>
class InstHyProcess : public HyProcess
{
typedef RETURN (CLASS::*METHOD)(ARG);
public:
CLASS * pClass;
METHOD * mMethod;
ARG  mArg;
RETURN mReturn;
InstHyProcess(CLASS *c, METHOD *m, ARG * a):pClass(c),mMethod(m),mArg(a){}

	sc_process_handle Spawn(){
		::sc_core::sc_spawn_options opt;
		 opt.set_stack_size(SC_THREAD_DEFAULT_STACK_SIZE);

		return sc_spawn(&mReturn, sc_bind(mMethod, pClass,mArg),0, &opt);

	}

};

template<typename RETURN, typename ARG>
class FunHyProcess : public HyProcess
{
public :
	typedef RETURN (*METHOD)(ARG);
	METHOD *mMethod;
	ARG mArg;
	sc_process_handle Spawn(){

	}

};

class Phase
{
std::vector<HyProcess *> m_Processes;

template<class C, typename RETURN, typename ARG >
 void Register(C *c, RETURN (C::*m)(ARG), ARG a){
	InstHyProcess<C, RETURN, ARG> *process = new  InstHyProcess<C, RETURN, ARG>(c, m, a);
	m_Processes.push_back(process);
  }

template<typename RETURN, typename ARG>
void Register(RETURN (*m)(ARG) , ARG a) {

}

};

#endif
