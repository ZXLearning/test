
#ifndef __WAIT_H__
#define __WAIT_H__

#include"testctrl.h"

void Wait(int t);

#endif
