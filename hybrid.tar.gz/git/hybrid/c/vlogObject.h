

template<string H = tb".core">
class VerilogObject{
    VerilogObject(string hier= H){
        m_object = acc_handle_object(hier)
    }
    bitvector  read();
    bool write(bitvector);
    privite:
        handle m_object;
        type m_type;
}
}
