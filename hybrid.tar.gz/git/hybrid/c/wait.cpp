
#include "wait.h"
#include "systemc.h"

void Wait(int t){

for(int i; i< t; i++)
{
	wait(event_manager::Instance()->Tick);
}

}
