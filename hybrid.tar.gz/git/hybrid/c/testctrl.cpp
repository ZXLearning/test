
#include "testctrl.h"
#include "systemc.h"
#include<stdlib.h>
#include<dlfcn.h>
#include "paramDB.h"

//class testctrl : public sc_module{
//public:
//	testctrl(sc_module_name nm);
//	virtual void run();
//	SC_HAS_PROCESS(testctrl);
//};
using namespace sc_core;


testctrl::testctrl(sc_module_name nm):
sc_module(nm)
{
	void * handle;
	SC_THREAD(run);
	sensitive<<StartOfSim;
	dont_initialize();

	SC_THREAD(EndTest);
	sensitive<<EndOfSim;
	dont_initialize();

	//_svScope = svGetScopeFromName("hybrid");
	//assert(_svScope);
	handle = dlopen("/proj/vmt_dev_1/xiazhang2/git/hw1/verif/csb_uvc/libtest2.so",RTLD_GLOBAL | RTLD_LAZY); // RTLD_LAZY);
	//handle = dlopen(paramDB::Instance()->getParam("testdll").c_str(), RTLD_GLOBAL | RTLD_LAZY);
	 if (!handle) {
        cerr << "Cannot open library: " << dlerror() << '\n';
        //return 1;
    }
	assert(handle);
	_pTestMain = (pTestMain)(dlsym(handle, "TestMain"));
	if (!_pTestMain) {
        cerr << "Cannot found TestMain: " << dlerror() << '\n';
        //return 1;
    }
	assert(_pTestMain);
	_pCreateHytb = (pCreateHytb) (dlsym(handle, "create_hytb"));
	assert(_pCreateHytb);
	_pCreateHytb();
//	dlclose(handle);
}

void testctrl::EndTest(){
	sc_stop();
}

void testctrl::run(){
//blank
//	wait(main_phase_start);   // use a calssss contain the event! 
//	wait(*(event_manager::Instance()->get_event()));
////	while(0 == tag ){ wait(10, SC_NS); cout<<"tag = "<<tag<<endl; } //can not accee static/global valibal by DPI
	//cout<<"main C test thread start!"<<endl;
	printf("main C test thread start!\n");
	test_main();
//	event_manager::Instance()->EndOfTest.notify();
//	EndOfSim.notify(0, SC_NS);
//	svSetScope(_svScope);
//	end_test();
}

void testctrl::test_main(){
ScMainPhase();
}

void testctrl::ScMainPhase(){  //spawn _spawnMainPhase
	sc_spawn( sc_bind(&testctrl::_spawnMainPhase, this));
}
void testctrl::_spawnMainPhase(){
	(*_pTestMain)();
	event_manager::Instance()->EndOfTest.notify();
if(paramDB::Instance()->getParam("MODE") == "SWEMU")
EndOfSim.notify(0, SC_NS);
	//svSetScope(_svScope);
	//end_test();
}

void testctrl::start_of_simulation()
{
	if(paramDB::Instance()->getParam("MODE") == "SWEMU")
	StartOfSim.notify(0, SC_NS);

}

//void end_test(){}

event_manager * event_manager::Instance(){
	if(instance) return instance;
	instance = new event_manager();
	return instance;

}

sc_event * event_manager::get_event(){
	return &main_phase;
}

event_manager * event_manager::instance = 0;
