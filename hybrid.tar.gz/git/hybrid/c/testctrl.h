
#include"systemc.h"
//#include "svdpi.h"
#include <sysc/kernel/sc_spawn.h>
#include <sysc/kernel/sc_spawn_options.h>
#include <sysc/kernel/sc_boost.h>
#include "testbench.h"


extern "C" void end_test();
extern "C" void Wait(int);
static sc_event main_phase_start;
static volatile int tag = 0;
extern "C" int TestMain();
typedef int (*pTestMain)();
typedef testbench* (*pCreateHytb)();

class testctrl : public sc_module{
public:
	testctrl(sc_module_name nm);
	void run();
	SC_HAS_PROCESS(testctrl);
	virtual void test_main();
	void ScMainPhase();  //spawn _spawnMainPhase
	void _spawnMainPhase(); //call testMain and phase done dpi
//	svScope _svScope;
	pTestMain _pTestMain;
	pCreateHytb _pCreateHytb;
	sc_event StartOfSim;
	sc_event EndOfSim;
	virtual void start_of_simulation();
	void EndTest();
};


#define TEST_MAIN(testname) class testname : public testctrl{ \
public: \
	testname(sc_core::sc_module_name nm); \
	void run(); \
	virtual void test_main(); \
}; \
 \
testname::testname(sc_core::sc_module_name nm): \
testctrl(nm) \
{} \
 \
 \
testctrl * CreateTest(){ \
	return new testname("#testname"); \
} \
 \
void testname::test_main()

#define TESTMAIN int TestMain



class event_manager;

class event_manager{
public:
	sc_event main_phase;
	sc_event Tick;
	sc_event EndOfTest;
	static event_manager * instance; 

	static event_manager * Instance();
	sc_event * get_event();

};

//event_manager * instance = 0;
