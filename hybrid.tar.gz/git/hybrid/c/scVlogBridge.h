
#include<acc_user.h>
#include<vpi_user.h>
#include<string.h>
#include<map>
#include"systemc.h"
#include<assert.h>
#include "tf_sc_syncer.h"
#include"signal/sc_vlog_signal.h"

using namespace sc_core;
using namespace std;
using namespace sc_dt;

extern "C" int vlog_callback(p_vc_record vc_record);


typedef enum DIRECTION
{
	SC2VLOG ,
	VLOG2SC ,
	DUALDIR 
} signal_dir;

class scVlogBridge : public sc_vlog_signal<sc_lv_base> { ///sc_signal<sc_lv<32>> {
	friend class sc_event;
public:
    scVlogBridge(string hier, signal_dir dir = SC2VLOG):sc_vlog_signal(){
		strcpy(user_data, hier.c_str());
        vlog = acc_handle_object(user_data);
		vlog2= vpi_handle_by_name(user_data, NULL);
        assert(vlog);
        m_len = acc_fetch_size(vlog);
        //m_cur_val.init(m_len);
        //user_data= hier.c_str();
		if(dir == VLOG2SC)
        acc_vcl_add(vlog, (int (*)())vlog_callback , user_data ,vcl_verilog_logic);

		m_value_new = new sc_lv_base("0",m_len);
		m_value_cur = new sc_lv_base("0",m_len);
     m_change_event_p = new sc_event("m_change_event_p");  
	 value_changed_event() ;
		direction = dir;
		assert(simcontext());
    }

	~scVlogBridge(){
		delete m_value_new;
		delete m_value_cur;
		if(direction == VLOG2SC)
			acc_vcl_delete(vlog, (int (*)())vlog_callback , user_data ,vcl_verilog_logic);
	}
//virtual const sc_lv_base& read() const;
    operator const sc_lv_base& () const;
    virtual void write( const sc_lv_base& ); // call by sc value change, update and write to vlog
	virtual void write(int v);
    void Write(p_acc_value value=0); // call by vlog callback to 
                                        //no read called from vlog
    void Update_();

    scVlogBridge & operator= ( const sc_lv_base& a)
	{write( a ); return *this;}
    scVlogBridge & operator= ( const sc_vlog_signal<sc_lv_base>& a){
	write( a.read() ); return *this;}
    
    virtual const sc_event& default_event() const
      { return value_changed_event(); }

    // get the value changed event
    virtual const sc_event& value_changed_event() const
    {   
        return *__sc_lazy_kernel_event( &m_change_event_p
                                    , "value_changed_event");
		  return *m_change_event_p;
    }   


    // read the current value
    // get a reference to the current value (for tracing)
    virtual const sc_lv_base& get_data_ref() const
        { sc_deprecated_get_data_ref(); return m_cur_val; }

	const sc_event*
__sc_lazy_kernel_event( sc_event** ev, const char* name ) const
{
    if ( !*ev ) { 
        std::string kernel_name = SC_KERNEL_EVENT_PREFIX "_";
        //kernel_name.append( name );
        *ev = new sc_event(name);//( kernel_name.c_str() );
    }   
    return *ev;

}

	virtual void update();
	void Write(const sc_lv_base & value_);

//	void request_update();
    // was there an event?
    virtual bool event() const
        { return simcontext()->event_occurred(m_change_stamp); }
	
	void write2vlog();
	void write2vlog2();

    public :
        handle vlog;
		vpiHandle vlog2;
        int m_len;
        char user_data[64];
        p_acc_value vlogValue;
        string vlogValueString;
		unsigned int vlogValueUint;
		sc_lv_base * m_value_cur;
		sc_lv_base * m_value_new;
		mutable sc_event*  m_change_event_p;
		sc_dt::uint64      m_change_stamp;
		signal_dir direction ;

     virtual const sc_lv_base& read() const
      { return *m_value_cur; }
	private:
	void do_update();

	void set_direction(signal_dir);

};



typedef scVlogBridge * scVlogBridgePtr;


class bridgeRegistry: public sc_module{
	bridgeRegistry(sc_module_name  nm):sc_module(nm){
		
	}


	
	private:
		static map<string, scVlogBridgePtr> bridges;
		static bridgeRegistry * pInstance;
	
	public:
	static scVlogBridgePtr get_bridge(string hier, signal_dir dir = SC2VLOG)
	{
	map< string, scVlogBridgePtr>::iterator  iter;
	for (iter= bridges.begin(); iter!=bridges.end(); iter++){
		if(iter->first == hier)
			{return  (iter->second);}
		}
	
	scVlogBridgePtr new_bridge = new scVlogBridge(hier, dir);
	bridges.insert(pair<string, scVlogBridgePtr>(hier, new_bridge));
	return new_bridge;
	}

	static bridgeRegistry *instance(){
	if (pInstance)
		return pInstance;
	pInstance = new bridgeRegistry("bridgeregistry");
	return pInstance;
	}
};



