
#ifndef __TESTBENCH_H__
#define __TESTBENCH_H__
#include "systemc.h"

class testbench : public sc_module
{
public:
	testbench(sc_module_name name):sc_module(name){}

};


#endif
