#include "scVlogBridge.h"
#include "stdio.h"
#include "tf_sc_syncer.h"

 map<string, scVlogBridgePtr> bridgeRegistry::bridges;
 bridgeRegistry* bridgeRegistry::pInstance = NULL;

extern "C" {

int vlog_callback(p_vc_record vc_record){
	char * hier;
	tfScSyncer tf;
	char mode[3] = "%b";
	handle obj = vc_record->out_value.vector_handle;
	scVlogBridgePtr bridge;
	hier = vc_record->user_data;
	bridge= bridgeRegistry::get_bridge(hier);
printf("callback trigger\n");
	if(vc_record->vc_reason == logic_value_change){
        switch(vc_record->out_value.logic_value){
                   case(vcl0): bridge->vlogValueString  = "0";
                   case(vcl1): bridge->vlogValueString  = "1";
                   case(vclX): bridge->vlogValueString  = "X";
                   case(vclz): bridge->vlogValueString  = "Z";
        }
//		printf("%s ---\n",bridge->vlogValueString.c_str());
 
    }
    else if(vc_record->vc_reason ==vector_value_change){
       
         //acc_fetch_value(handle, %%,bridge->vlogValue);
		 assert(obj);
         bridge->vlogValueString = acc_fetch_value(obj, mode, NULL);
    }
	bridge->vlogValueString = acc_fetch_value(obj, mode, NULL);
//	printf("%s,,,,%s, %s\n", bridge->vlogValueString.c_str(), hier, acc_fetch_value(obj, mode, NULL));
	bridge->Update_();

	//tf.ScEval();
	//   sc_start(SC_ZERO_TIME); same stack overflow




}

}

void scVlogBridge::Update_(){
	sc_lv_base lv(vlogValueString.c_str());
	Write(lv);
	}

void scVlogBridge::write(const sc_lv_base & value_){
cout<<"write :"<<value_ <<endl;
	bool value_changed = !( *m_value_cur == value_ );
	*m_value_new = value_;
	*m_value_cur = value_;
	//if(value_changed) update();
	if(value_changed)
	{	vlogValueString = value_.to_string();
		vlogValueUint = value_.to_uint();
		write2vlog2();
	}

}

void scVlogBridge::write(int v){
sc_lv_base v_;
v_ = v;
write(v_);

}

void scVlogBridge::Write(const sc_lv_base & value_)
{
	bool value_changed = !( *m_value_cur == value_ );
	*m_value_new = value_;
	//request_update();
	if(value_changed) update();

}

void
scVlogBridge::update()
{
    policy_type::update();
    //if( !( *m_value_new == *m_value_cur ) ) { 
        do_update();
    //}   
}

void
scVlogBridge::do_update()
{
    *m_value_cur = *m_value_new;
	value_changed_event();
    if ( m_change_event_p ) m_change_event_p->notify(SC_ZERO_TIME);
	printf("m_change_evnet.trigger\n");
    m_change_stamp = simcontext()->change_stamp();
//	ScEval();
}

void scVlogBridge::write2vlog(){
s_setval_value set_val;
s_setval_delay delay_s;
char vstr[128];

int rst;

set_val.format = accIntVal;//accBinStrVal;
strcpy(vstr, vlogValueString.c_str());
set_val.value.integer = vlogValueUint;//vstr;
delay_s.model = accAssignFlag ;//accNoDelay;
//delay_s.time = NULL;
rst = acc_set_value(vlog, &set_val, &delay_s);

cout<<"writing to vlog:"<<vlogValueUint<<":"<<rst<<endl;


}
void scVlogBridge::write2vlog2(){
s_vpi_value set_val;
s_vpi_time delay_s = { vpiSimTime, 0, 0, 0.0 };;
char vstr[128];
t_vpi_vecval vec;

int rst = 0;

set_val.format = vpiVectorVal;//accBinStrVal;
strcpy(vstr, vlogValueString.c_str());
set_val.value.integer = vlogValueUint;//vstr;
vec.aval = vlogValueUint;
vec.bval = 0;//vlogValueUint;
set_val.value.vector = &vec;
//delay_s.model = //accAssignFlag ;//accNoDelay;
//delay_s.time = NULL;
vpi_put_value(vlog2, &set_val, &delay_s, vpiNoDelay);

cout<<"writing2 to vlog:"<<vlogValueUint<<":"<<rst<<endl;


}

void scVlogBridge::set_direction(signal_dir dir){
	if(dir == direction)
		return;
	direction = dir;
	if(direction == VLOG2SC)
        acc_vcl_add(vlog, (int (*)())vlog_callback , user_data ,vcl_verilog_logic);

}
//int main(){}
