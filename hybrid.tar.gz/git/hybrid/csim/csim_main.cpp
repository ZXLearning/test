#include<stdio.h>
#include "systemc.h"
#include "vcsuser.h"
#include "acc_user.h"
#include "svdpi.h"
#include<iostream>
#include<dlfcn.h>
#include<cstring>
//#include "tf_sc_syncer.h"
#include"testctrl.h"
//#include "scVlogBridge.h"
#include "paramDB.h"
#include "assert.h"

extern "C" {
void Wait(int t);
void Wait_(int t );
//void dpi_fun();
//int cpp_test_thread();
void hydra_dpi_sc_sync();
void hydra_dpi_sc_eval();
//void main_start();
void MainPhase();
}
//class hytb;
//hytb * create_hytb();
// hytb (*pCreateHytb)();
static testctrl *ptest;
static sc_event Tick;
static svScope scope = NULL;
void Wait(int t){
	//for(int i =0; i<t; i++){
	//wait(Tick);
  //   tfScSyncer tf;
	// tf.Wait(t);
//}
}

sc_event * getTick()
{
	return &Tick;
}


void main_start(){
	//main_phase_start.notify();  //use classs :: instance caontain the event.
	event_manager::Instance()->get_event()->notify();
	printf("trigger tag  = 1\n");
	tag = 1;
	printf("tag == %d now\n", tag);
	  do {
      sc_start(SC_ZERO_TIME);   // Initialize SystemC
  } while (sc_pending_activity_at_current_time());
}

int main(){
     int acc_argc;
     char **acc_argv;
  //_svscope = (*_svGetScopeFromName)("top");//svGetScope();
  //scope = svGetScopeFromName("hybrid");
  //assert(_svscope);
    //  acc_argc = acc_fetch_argc();
    //  acc_argv = acc_fetch_argv();
       int exit_code = sc_core::sc_elab_and_sim(acc_argc, acc_argv);       // calls:  sc_main()

        return exit_code;
for(int i =0; i<100;i++){
//Wait(100);
printf("10 ns ...");
}

}

class producer_uvm : public sc_module{
public:
  sc_lv<4> vlog;
  producer_uvm(sc_module_name nm):vlog(0) {
 //      bridge_port.bind(BridgeRegistry::instsnce()->get_bridge("tb.clk"));
      SC_THREAD(run);
//		sensitive<<bridge_port;
   }
   SC_HAS_PROCESS(producer_uvm);
   void run() {
	for(int i =0; i<1000000;i){
		//Wait_(100);
	//wait(	bridge_port->default_event());
		//next_trigger();//(1, SC_NS);
	//	wait(10, SC_NS);
		vlog = i;
		printf("100 ns ...\n");
		wait(12,SC_NS);
//		sc_start(SC_ZERO_TIME);
		if(paramDB::Instance()->getParam("MODE") == "SWEMU");
		event_manager::Instance()->Tick.notify(0,SC_NS);
		//cout<<bridge_port->read()<<endl;
	}
   }

};

 int sc_main(int argc, char* argv[])
 {
 #define SC_MAKE_VERSION( x, y, z ) \
   (((x)*10000) + ((y)*100) + (z))
 //FILTER msg: Warning: (W571) no activity or clock movement for sc_start() invocation
   #if SC_MAKE_VERSION(SC_VERSION_MAJOR,SC_VERSION_MINOR,SC_VERSION_PATCH) >= SC_MAKE_VERSION(2,3,0)
       sc_core::sc_report_handler::set_actions( sc_core::SC_ID_NO_SC_START_ACTIVITY_, sc_core::SC_DO_NOTHING );
   #endif

 static  producer_uvm prod("producer");
 ///static hytb* phytb = create_hytb();
// static bridgeRegistry * bridgereg= bridgeRegistry::instance();


 paramDB::Instance()->setParam("MODE", "SWEMU");
 paramDB::Instance()->setParam("testdll", "/proj/vmt_dev_1/xiazhang2/git/hw1/verif/csb_uvc/libtest2.so");
   paramDB *p = paramDB::Instance();
   std::map<string, string>::iterator  it;
    for (it = p->Params.begin(); it != p->Params.end(); ++it)
    {
        std::cout << "key" << it->first << std::endl;
        std::cout << "value" << it->second << std::endl;
    }
std::cout<<"PINTing MODE "<< paramDB::Instance()->getParam("MODE").c_str()<<std::endl;
// prod.bridge_port.bind(*bridgeRegistry::instance()->get_bridge("top.tester2"));
 ptest = new testctrl("testctrl");//CreateTest();
// bridgeRegistry::instance()->get_bridge("top.tester", VLOG2SC);
   srand(rand());
   sc_start(SC_ZERO_TIME);
   sc_start(SC_ZERO_TIME);
   sc_start(SC_ZERO_TIME);
	   sc_start();//(1000000, SC_NS);//(SC_ZERO_TIME);
	     return 0;
 }

//-------------------------------------------------------------------------------------
// hydra_dpi_sc_sync:
//  dpi version of the sc_sync
//
//-------------------------------------------------------------------------------------

