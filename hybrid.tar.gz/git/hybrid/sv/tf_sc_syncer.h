// -*- c++ -*-
// Copyright (c) 2004-2016 Advanced Micro Devices, Inc. All rights reserved.

#ifndef __TF_SC_DRIVER_H__
#define __TF_SC_DRIVER_H__

#include <vector>
#include <string>
#include <systemc.h>
//#include "cmntypes.h"
//#include "hydra.h"

class tfScSyncer;
typedef tfScSyncer * tfScSyncerPtr ;                         ///< Typedef pointer to tfScSyncer 

///@{ @class tfScSyncer
///@brief SystemC updater
class tfScSyncer { 
public:
  tfScSyncer () ;             ///< Constructor
  virtual ~ tfScSyncer() { } ;                          ///< Virtual Destructor
  
  void ScSync () ;                                 ///< Bring SystemC to Match Verilog Time
  void ScEval () ;                                 ///< Allow notification to take place
  void Wait(int nclks);
  void Notify();

protected:


  sc_time_unit        mScTimePrec ;                /// Translation of tf_gettimeunit to sc_time_unit
  uint32_t             mScTimeMul ;                   /// Time multiplier 1 NS 10 NS 100 NS
  static sc_event Tick;
} ; 


extern "C" {
  void SYNC();
  void EVAL();
  }

#endif

