// Copyright (c) 2004-2016 Advanced Micro Devices, Inc. All rights reserved.

#include "tf_sc_syncer.h"
//#include "hydra_pli_user.h"  // Brings in vendor specific veriuser.h
#include <vpi_user.h>
#include<veriuser.h>
#include<stdio.h>

using std::string ; 

// Convert a time code returned by tf_gettimeprecsion or tf_
static sc_time_unit
time_code_to_sc_time(int time_code)
{
  switch (time_code) { 
    case   2 :
    case   1 :
    case   0 : return(SC_SEC);
    case  -1 :
    case  -2 :
    case  -3 : return(SC_MS);
    case  -4 :
    case  -5 :
    case  -6 : return(SC_US);
    case  -7 :
    case  -8 :
    case  -9 : return(SC_NS);
    case -10 :
    case -11 :
    case -12 : return(SC_PS);
    case -13 :
    case -14 :
    case -15 : return(SC_FS);
    default:
      string error_msg = "tfScSyncer::tfScSyncer: Unable to decode tf_gettimeunit() " ; 
      throw error_msg ; 
  }
}

sc_event tfScSyncer::Tick;

tfScSyncer::tfScSyncer ( ) :
  mScTimeMul(1)
{

  mScTimePrec = time_code_to_sc_time(tf_igettimeprecision(0));

  // 2=>100, 1=>10, 0=>1, -1=>100, etc. to -15=>1
  int i;
  for (i = tf_igettimeunit(0); i % 3 != 0; --i)
    mScTimeMul *= 10;


}

void
tfScSyncer::ScSync ( ) 
{
  // this needs acc=rw:hydra in the tab file
  s_vpi_time vpi_time;
  vpi_time.type = vpiSimTime;
  vpi_get_time(0, &vpi_time);

  uint64 current_verilog_time = (static_cast<uint64>(vpi_time.high) << 32) | 
                                 vpi_time.low;
  current_verilog_time *= mScTimeMul;

  sc_time current_verilog_sc_time = sc_time(static_cast<double>(current_verilog_time), mScTimePrec);
  sc_time current_sysc_sc_time    = sc_time_stamp();
  if ( current_verilog_sc_time >= current_sysc_sc_time ) { 
    sc_time delta_time = current_verilog_sc_time - current_sysc_sc_time;
    sc_start(delta_time) ; 
  } else { 
    string error_msg = "tfScSyncer::ScSync: Whoa! SystemC has gotten ahead of Verilog!" ; 
    throw error_msg ; 
  }
}

void
tfScSyncer::ScEval ( ) {
  do {
    sc_start(SC_ZERO_TIME); 
  } while (sc_pending_activity_at_current_time());
}
 
void tfScSyncer::Wait(int nclks){
	for(int i=0; i<nclks; i++)
		wait(Tick);

}
void tfScSyncer::Notify(){
	Tick.notify();
	//printf("tfScSyncer::Notify\n");
}

extern "C" {
void SYNC(){
tfScSyncer tf;
tf.ScSync();

}

void EVAL(){
tfScSyncer tf;
tf.ScEval();
}
}
