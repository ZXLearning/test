/*********************************************************************
 * SYNOPSYS CONFIDENTIAL                                             *
 *                                                                   *
 * This is an unpublished, proprietary work of Synopsys, Inc., and   *
 * is fully protected under copyright and trade secret laws. You may *
 * not view, use, disclose, copy, or distribute this file or any     *
 * information contained herein except pursuant to a valid written   *
 * license from Synopsys.                                            *
 *********************************************************************/


#include "vcsuser.h"
#include "vpi_user.h"
//#include "tf_sc_driver.h"
 //void vcs_systemc_init();



#ifdef __cplusplus
extern "C" {
#endif

 void SYNC();
 void EVAL();
 static int systemc_sync(p_cb_data cb_data_p)
 {
	EVAL();
 }
//int hydra_uvm_dpi_build();
int cpp_test_thread();
static int setup_sc(p_cb_data cb_data_p)
{
	cpp_test_thread();
}

PLI_INT32 PLIbook_MyMonitor_callback(p_cb_data cb_data_p)
{
vpi_printf("At time 0.2f:\t  = s\n");//,
//cb_data_p->time->real,
//cb_data_p->value->value.str);
return(0);
}

static int vcs_systemc_init ( p_cb_data cb_data_p )
 {
//	TfScDriver tf;
	static int skip = 1;
	vpiHandle handle;
	s_vpi_time current_time;
	s_cb_data cbDataValue;
	current_time.type = vpiScaledRealTime;
	vpi_get_time(0, &current_time);
	if(!skip){ 
	SYNC();
	EVAL();}
	vpi_printf("\nAt time %2.2f, SYNCed :\n",current_time.real);
	//skip = 0;
	handle = vpi_handle_by_name("sv_main.clk", 0);
	cbDataValue.obj = handle;
	cbDataValue.reason = cbValueChange;
	cbDataValue.cb_rtn = PLIbook_MyMonitor_callback;
	//vpi_printf( "===: Time Phase..\n");
	s_cb_data cbData = {cbNextSimTime, vcs_systemc_init,0, 0, 0};//{ cbNextSimTime, vcs_systemc_init, 0, 0, 0 };
	//if(skip)
	vpi_register_cb(&cbData);
	s_cb_data cbData2 = {cbNBASynch, systemc_sync, 0,0,0};
	vpi_register_cb(&cbData2);
	if(skip)
	vpi_register_cb(&cbDataValue);
	s_cb_data cbData3 = {cbStartOfSimulation, setup_sc, 0,0,0};
	vpi_register_cb(&cbData3);
	//tf_rosynchronize();
	skip = 0;
	return(1);
}
static void c_main(void){
	//hydra_uvm_dpi_build();
	vcs_systemc_init(0);
}
char* say( int reason )
{
    switch ( reason )
    {
        case reason_calltf:       return( "calltf" );
        case reason_checktf:      return( "checktf" );
        case reason_sizetf:       return( "sizetf" );
        /*
         * Misc function reasons
         */
        case reason_endofcompile: return( "endofcompile" );
        case reason_paramvc:      return( "paramvc" );
        case reason_paramdrc:     return( "paramdrc" );
        case reason_synch:        return( "synch" );
        case reason_rosynch:      return( "rosynch" );
        case reason_reactivate:   return( "reactivate" );
        case reason_force:        return( "force" );
        case reason_release:      return( "release" );
        case reason_disable:      return( "disable" );
        case reason_interactive:  return( "interactive" );
        case reason_scope:        return( "scope" );
        case reason_startofsave:  return( "startofsave" );
        case reason_save:         return( "save" );
        case reason_restart:      return( "restart" );
        case reason_reset:        return( "reset" );
        case reason_endofreset:   return( "endofreset" );
        case reason_finish:       return( "finish" );
        /*
         * Just in case...
         */
        default:                  return( "unknown" );
    }
}

void myCheck( int data, int reason )
{
    int i, nump = tf_nump( );

    io_printf( "check (%d) function called at %d (%s)\n", data, tf_gettime( ), say( reason ) );

    io_printf( "-- %d parameters passed\n", nump );

    for ( i = 1; i <= nump; i++ )
    {
        io_printf( "-- parameter %d is ", i );

        switch ( tf_typep( i ) )
        {
            case tf_nullparam:     io_printf( "a null" );          break;
            case tf_string:        io_printf( "a string" );        break;
            case tf_readonly:      io_printf( "a readonly" );      break;
            case tf_readwrite:     io_printf( "a readwrite" );     break;
            case tf_readonlyreal:  io_printf( "a readonlyreal" );  break;
            case tf_readwritereal: io_printf( "a readwritereal" ); break;
            default:               io_printf( "an undefined" );    break;
        }
        io_printf( " parameter of size %d\n", tf_sizep( i ) );
    }

}
 
void myCall( int data, int reason )
{
    io_printf( "call (%d) function called at %d (%s)\n", data, tf_gettime( ), say( reason ) );

    io_printf( "-- setting async callbacks\n" ); tf_asynchon( );
}
 
void myMisc( int data, int reason, int paramvc )
{
    io_printf( "misc (%d) function called at %d (%s)\n", data, tf_gettime( ), say( reason ) );

    if ( ( reason == reason_paramvc ) || ( reason == reason_paramdrc ) )
    {
        io_printf( "-- apparently called because parameter %d changed\n", paramvc );

        io_printf( "-- setting reactivation in 5 ticks\n" ); tf_setdelay( 5 );
    }
}

int mytest_misc(int user_data, int reason) {
	io_printf( "Mtest misc calling...\n" );
  if (reason == reason_endofcompile)  tf_rosynchronize();
    if (reason == reason_rosynch){
		io_printf( "mytest misc\n" );
//		hydra_uvm_dpi_build();
		vcs_systemc_init(0);
		}
		return 0;
	  }
void (*vlog_startup_routines[])(void) = { 
    c_main,
    0   
};




#ifdef __cplusplus
}
#endif
