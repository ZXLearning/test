#include <string>
//#include "hydra.h"
#include "systemc.h"
//#include "hydra_pli.h"
#include"tf_sc_syncer.h"

extern sc_event* getTick();

extern "C"
{
    int hydra_pli_tick_misctf(int user_data, int reason);
    int hydra_pli_signal_negedge_event_misctf(int user_data, int reason);
    int hydra_init_misctf (int user_data, int reason);
	int hybrid_pli_tick();
}


int
hybrid_pli_tick ()
{
  
  sc_event * Tick = getTick();
  tfScSyncer tf;
  SYNC();
  //Tick->notify();
  tf.Notify();
  EVAL();
  
  return 0 ;
}
